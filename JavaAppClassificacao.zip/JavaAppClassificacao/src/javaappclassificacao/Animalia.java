
package javaappclassificacao;

public class Animalia {
    private String des;
    
    public String obterDes(){
        return "Reino Animalia";
    }
}
