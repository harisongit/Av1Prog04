
package javaappclassificacao;


public class Chordata extends Animalia{

    @Override
    public String obterDes() {
        return super.obterDes()+"\nFilo Chordata"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
