
package javaappclassificacao;


public class CanisFamiliaris extends Canis{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nEspecie Canis familiaris"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
