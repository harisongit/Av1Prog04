
package javaappclassificacao;


public class JavaAppClassificacao {


    public static void main(String[] args) {
        HomoSapiens homem = new HomoSapiens();
        CanisFamiliaris cao=new CanisFamiliaris();
        MuscaDomestica mosca=new MuscaDomestica();
        
        //System.out.println(homem.obterDes());
        //System.out.println(cao.obterDes());
        System.out.println(mosca.obterDes());
    }
    
}
