
package javaappclassificacao;


public class HomoSapiens extends Homo{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nEspecie Homo sapiens"; //To change body of generated methods, choose Tools | Templates.
    }
}
