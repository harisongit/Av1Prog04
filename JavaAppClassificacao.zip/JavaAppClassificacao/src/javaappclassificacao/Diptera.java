
package javaappclassificacao;


public class Diptera extends Insecta {
    @Override
    public String obterDes() {
        return super.obterDes()+"\nOrdem Díptera"; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
