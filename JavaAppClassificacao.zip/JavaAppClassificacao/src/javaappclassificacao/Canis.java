
package javaappclassificacao;


public class Canis extends Canidae{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nGenero Canis"; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
