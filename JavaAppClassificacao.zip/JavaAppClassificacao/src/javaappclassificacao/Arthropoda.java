
package javaappclassificacao;


public class Arthropoda extends Animalia{

    @Override
    public String obterDes() {
        return super.obterDes()+"\nArthropoda"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
