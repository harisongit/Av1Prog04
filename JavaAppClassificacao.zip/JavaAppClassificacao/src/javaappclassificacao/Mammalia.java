
package javaappclassificacao;

public class Mammalia extends Chordata{

    @Override
    public String obterDes() {
        return super.obterDes()+"\nClasse Mammalia"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
