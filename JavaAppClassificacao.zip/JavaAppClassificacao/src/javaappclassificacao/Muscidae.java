
package javaappclassificacao;

public class Muscidae extends Diptera{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nFamilia Muscidae"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
