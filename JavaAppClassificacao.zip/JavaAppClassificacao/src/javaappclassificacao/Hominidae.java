
package javaappclassificacao;


public class Hominidae extends Primata {
    @Override
    public String obterDes() {
        return super.obterDes()+"\nFamilia Hominidae"; //To change body of generated methods, choose Tools | Templates.
    }
   
}
