
package javaappclassificacao;


public class Primata extends Mammalia{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nOrdem Primata"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
