
package javaappclassificacao;


public class Musca extends Muscidae{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nGenero Musca"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
