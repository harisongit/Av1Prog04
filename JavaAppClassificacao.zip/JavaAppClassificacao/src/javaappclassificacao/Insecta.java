
package javaappclassificacao;


public class Insecta extends Arthropoda{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nClasse Insecta"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
