
package javaappclassificacao;


public class Homo extends Hominidae {
    @Override
    public String obterDes() {
        return super.obterDes()+"\nGenero Homo"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
