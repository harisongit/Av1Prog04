
package javaappclassificacao;

public class Carnivora extends Mammalia {

    @Override
    public String obterDes() {
        return super.obterDes()+"\nOrdem Carnívora"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
