
package javaappclassificacao;


public class Canidae extends Carnivora{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nFamilia Canidae"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
