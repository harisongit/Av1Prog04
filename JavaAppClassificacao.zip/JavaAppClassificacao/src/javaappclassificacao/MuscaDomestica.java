
package javaappclassificacao;


public class MuscaDomestica extends Musca{
    @Override
    public String obterDes() {
        return super.obterDes()+"\nEspecie Musca domestica"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
